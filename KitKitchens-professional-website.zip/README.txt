KITKITCHENS.COM PROFESSIONAL WEBSITE

Upload these two files together:
- index.html
- kitkitchens-logo.png

The website is ready to publish.

The page currently displays:
Closing date to be confirmed

Once the final deadline is decided, replace that wording inside index.html.
